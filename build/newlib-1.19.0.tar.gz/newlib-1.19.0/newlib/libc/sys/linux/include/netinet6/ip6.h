/*	$FreeBSD: src/sys/netinet6/ip6.h,v 1.5 2000/07/04 16:35:09 itojun Exp $	*/
/*	$KAME: ip6.h,v 1.7 2000/03/25 07:23:36 sumikawa Exp $	*/

#error "netinet6/ip6.h is obsolete.  use netinet/ip6.h"
