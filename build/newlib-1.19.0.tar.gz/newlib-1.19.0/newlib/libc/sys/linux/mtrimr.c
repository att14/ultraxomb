#include <stdlib.h>

void *
_malloc_trim_r (struct _reent *ptr, size_t pad)
{
  return 0;
}
